package com.miniproject.foodapp.request;

import lombok.Data;

@Data
public class Home
{
    private String restaurantName;
    private float rating;
    private float avgRating;
    private int restaurantId;
    private boolean freeDelivery;
    private String photoUrl;
}
