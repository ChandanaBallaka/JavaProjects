package com.robosoft.Evaluation2.controller;

import com.robosoft.Evaluation2.entity.BookAppointment;
import com.robosoft.Evaluation2.entity.Doctor;
import com.robosoft.Evaluation2.entity.Patient;
import com.robosoft.Evaluation2.service.HelpdeskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelpdeskController
{
    @Autowired
    HelpdeskRepository helpdeskRepository;

    @PostMapping("/addPatients")
    public String registerPatient(@RequestBody Patient p)                           //patient registration through helpdesk
    {
        helpdeskRepository.registerPatient(p);
        return "Patient with name " + p.getPatientName() + " Registered successfully";
    }

    @PostMapping("/bookingappointment/{doctorId}")
    public String bookingAppointment(@RequestBody BookAppointment bookAppointment, @PathVariable int doctorId, @RequestBody Doctor doctor)             //patient getting appointment through helpdesk
    {
        int result = helpdeskRepository.bookingAppointment(bookAppointment,doctorId,doctor);
        if(result == 0)
        {
            return "Unable to book appointment";
        }
        return "Booked Successfully";
    }
}
