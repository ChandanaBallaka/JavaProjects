package com.robosoft.Evaluation2.entity;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class Doctor
{
    private int doctorId;
    private String doctorName;
   // private int fileNumber;
    private int maxPatient;
    private int currentPatient;
    private String departmentName;  //one department have many doctors
  //  private int wardNumber;
}
