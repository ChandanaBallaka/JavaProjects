package com.robosoft.Evaluation2.service;

import com.robosoft.Evaluation2.entity.Doctor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class DepartmentRepository
{
    @Autowired
    JdbcTemplate jdbcTemplate;

    // search doctor by his name
    public Doctor searchDoctor(String doctorName)
    {

        String search_for_doctor = "select * from doctor where doctorName = ?";
        try
        {
            return jdbcTemplate.queryForObject(search_for_doctor, new Object[]{doctorName}, new BeanPropertyRowMapper<>(Doctor.class));
        }
        catch (Exception e)
        {
            return  null;
        }

    }
}
