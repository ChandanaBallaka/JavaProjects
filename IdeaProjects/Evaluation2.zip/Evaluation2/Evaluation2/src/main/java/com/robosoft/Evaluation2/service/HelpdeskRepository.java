package com.robosoft.Evaluation2.service;

import com.robosoft.Evaluation2.entity.BookAppointment;
import com.robosoft.Evaluation2.entity.Doctor;
import com.robosoft.Evaluation2.entity.Patient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class HelpdeskRepository
{
    @Autowired
    JdbcTemplate jdbcTemplate;

    public void registerPatient(Patient p)                //patient registration through helpdesk
    {
        String register_patient = " insert into patient(patientName,patientAge,patientGender,phoneNumber) values(?,?,?,?)";
        jdbcTemplate.update(register_patient,p.getPatientName(),p.getPatientAge(),p.getPatientGender(),p.getPhoneNumber());
    }

    public int bookingAppointment(BookAppointment bookAppointment, int doctorId, Doctor doctor)       //patient taking appointment through helpdesk
    {

        int count = jdbcTemplate.queryForObject("select maxPatient from doctor where doctorId = ?", Integer.class,new Object[]{bookAppointment.getDoctorId()});
        if(count>=doctor.getDoctorId())
        {
            String book_appointment = "insert into bookappointment values(?,?)";
            jdbcTemplate.update(book_appointment,bookAppointment.getAppointmentNumber(),bookAppointment.getPatientId(),bookAppointment.getDoctorId());
            String update_doctor = "update doctor set maxPatient=? where doctorId=?";
            jdbcTemplate.update(update_doctor,new Object[]{count-doctor.getMaxPatient(),doctor.getDoctorId()});

        }
       return 0;
    }
}
