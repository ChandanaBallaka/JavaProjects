package com.robosoft.Evaluation2.entity;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class CheckUpPatient
{
    private int checkUpNumber;
    private int appointmentNumber;
}
