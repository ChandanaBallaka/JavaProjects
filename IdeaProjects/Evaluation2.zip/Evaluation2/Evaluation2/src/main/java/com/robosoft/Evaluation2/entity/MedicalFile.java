package com.robosoft.Evaluation2.entity;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class MedicalFile
{
    private int fileNumber;
    private int patientId;
   // private int reportNumber;
}
