package com.robosoft.Evaluation2.service;

import com.robosoft.Evaluation2.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class HospitalRepository
{
    @Autowired
    JdbcTemplate jdbcTemplate;

    public void addHospital(Hospital hospital)
    {
        String insert_into_hospital = " insert into hospital(hospitalName) values(?)";
        jdbcTemplate.update(insert_into_hospital,hospital.getHospitalName());
    }

    //Searching for a patient
    public Patient searchPatient(int patientId)
    {

        String search_for_patient = "select * from patient where patientId = ?";
        try
        {
            return jdbcTemplate.queryForObject(search_for_patient, new Object[]{patientId}, new BeanPropertyRowMapper<>(Patient.class));
        }
        catch (Exception e)
        {
            return  null;
        }

    }

    public void addDepartment(Department department)
    {
        String insert_into_department = "insert into department values(?,?)";
        jdbcTemplate.update(insert_into_department,department.getDepartmentName(),department.getHospitalName());
    }

    public void addWard(Ward ward)
    {
        String insert_into_ward = "insert into ward values(?,?)";
        jdbcTemplate.update(insert_into_ward,ward.getWardNumber(),ward.getNo_of_seats());
    }

    public void addDoctor(Doctor doctor)
    {
        String insert_into_doctor = "insert into doctor(doctorName,maxPatient,currentPatient,departmentName) values(?,?,?,?)";
        jdbcTemplate.update(insert_into_doctor,doctor.getDoctorName(),doctor.getMaxPatient(),doctor.getCurrentPatient(),doctor.getDepartmentName());
    }

    public void generatingMedicalFile(MedicalFile medicalFile)
    {
        String generate_file = "insert into medicalfile(patientId) values(?)";
        jdbcTemplate.update(generate_file,medicalFile.getPatientId());
    }

    public void updateMedicalFile(MedicalFile medicalFile,int fileNumber)                               //updating medical file
    {
        String update_file = "Update customer set patientId = ? where fileNumber = ?";
    }
}
