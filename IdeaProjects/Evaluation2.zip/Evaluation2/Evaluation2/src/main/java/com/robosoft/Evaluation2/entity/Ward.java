package com.robosoft.Evaluation2.entity;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class Ward
{
    private int wardNumber;
    private int no_of_seats;
    //private int patientId;            //one ward consist of many patients
}
