package com.jwt.example.jwtbasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtbasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
