package com.jwt.example.jwtbasic.models;

import java.io.Serializable;

public class JwtResponseModel implements Serializable
{
}
