package com.jwt.example.jwtbasic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtbasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtbasicApplication.class, args);
	}

}
